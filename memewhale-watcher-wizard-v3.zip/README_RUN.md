# MemeWhale Watcher (Wizard v3)

## Quickstart

1. Unzip the project.
2. Install deps:
   ```bash
   npm install
   ```
3. Run:
   ```bash
   npm start
   ```

- On first run, wizard will ask API keys & save `.env`.
- You can re-run config anytime:
   ```bash
   npm run setup
   ```
