// config-wizard.js
const fs = require('fs');
const prompt = require('prompt-sync')();
require('dotenv').config();

console.log("\n🔧 MemeWhale Watcher - Setup Wizard\n");

let existing = {};
if (fs.existsSync('.env')) {
  const lines = fs.readFileSync('.env','utf8').split(/\r?\n/);
  for (const l of lines) {
    if (!l.trim() || l.startsWith('#')) continue;
    const [k,v] = l.split('=');
    existing[k] = v;
  }
}

function ask(key, question, def="") {
  if (existing[key]) return existing[key];
  const ans = prompt(question + (def?` (default ${def})`: "") + ": ");
  return ans || def;
}

const config = {};
config.ALCHEMY_API_KEY = ask('ALCHEMY_API_KEY','Enter your Alchemy API Key');
config.COVALENT_API_KEY = ask('COVALENT_API_KEY','Enter your Covalent API Key (optional)');
config.TELEGRAM_BOT_TOKEN = ask('TELEGRAM_BOT_TOKEN','Enter your Telegram Bot Token');
config.TELEGRAM_CHAT_ID = ask('TELEGRAM_CHAT_ID','Enter your Telegram Chat ID');
config.GRAPHQL_ENDPOINT = existing.GRAPHQL_ENDPOINT || "https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v2";
config.PORT = ask('PORT','Enter Port', "3000");
config.CHAIN_ID = ask('CHAIN_ID','Enter Chain ID (1=ETH,56=BSC)', "1");
config.WHALER_MIN_ETH = ask('WHALER_MIN_ETH','Min ETH to count as whale buy', "50");

let envContent = "";
for (const [k,v] of Object.entries(config)) {
  envContent += `${k}=${v}\n`;
}
fs.writeFileSync('.env', envContent);
console.log("\n✅ Configuration saved to .env.\n");
