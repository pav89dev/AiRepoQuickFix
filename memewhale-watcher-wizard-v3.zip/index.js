// index.js
require('dotenv').config();

// Fetch polyfill for Node <18
if (typeof fetch === "undefined") {
  global.fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
}

const express = require('express');
const bodyParser = require('body-parser');
const { Alchemy, Network } = require('alchemy-sdk');
const { request, gql } = require('graphql-request');
const axios = require('axios');

const app = express();
app.use(bodyParser.json());

const {
  ALCHEMY_API_KEY,
  GRAPHQL_ENDPOINT,
  COVALENT_API_KEY,
  TELEGRAM_BOT_TOKEN,
  TELEGRAM_CHAT_ID,
  PORT = 3000,
  CHAIN_ID = "1",
  WHALER_MIN_ETH = 50
} = process.env;

if (!ALCHEMY_API_KEY) console.warn("⚠️ ALCHEMY_API_KEY not set — fill .env or rerun wizard.");

const settings = {
  apiKey: ALCHEMY_API_KEY || '',
  network: Network.ETH_MAINNET,
};
const alchemy = new Alchemy(settings);

const trackedWallets = new Map();
const recentSignals = new Map();

async function sendTelegram(text) {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) return console.log("[Alert suppressed]", text);
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  try {
    await axios.post(url, { chat_id: TELEGRAM_CHAT_ID, text, parse_mode: 'Markdown' });
  } catch (e) {
    console.error("Telegram error:", e.response?.data || e.message);
  }
}

async function getHolderCount(chainId, tokenAddress) {
  if (!COVALENT_API_KEY) return null;
  const url = `https://api.covalenthq.com/v1/${chainId}/tokens/${tokenAddress}/token_holders/?key=${COVALENT_API_KEY}&page-size=1`;
  try {
    const res = await axios.get(url);
    return res.data?.data?.pagination?.total_count ?? null;
  } catch (e) {
    console.warn("Covalent holders failed:", e.message);
    return null;
  }
}

async function scoreToken(tokenAddress, buys) {
  let score = 0;
  const totalEth = buys.reduce((s, b) => s + b.valueEth, 0);
  const uniqueWhales = new Set(buys.filter(b => b.valueEth >= Number(WHALER_MIN_ETH)).map(b => b.wallet)).size;

  if (uniqueWhales >= 3) score += 40;
  else if (uniqueWhales == 2) score += 25;
  else if (uniqueWhales == 1) score += 10;

  if (buys.length >= 5 && totalEth >= 10) score += 20;

  if (totalEth >= 100) score += 20;
  else if (totalEth >= 20) score += 10;

  const holders = await getHolderCount(CHAIN_ID, tokenAddress);
  if (holders && holders > 2000) score += 10;

  return { score, totalEth, uniqueWhales, holders };
}

let lastBlockChecked = null;
async function pollRecentTransfers() {
  try {
    const block = await alchemy.core.getBlockNumber();
    if (!lastBlockChecked) lastBlockChecked = block - 1;
    if (block <= lastBlockChecked) return;

    const from = lastBlockChecked + 1;
    const to = block;
    lastBlockChecked = block;

    console.log(`Scanning blocks ${from}..${to}`);

    const transferTopic = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
    const logs = await alchemy.core.getLogs({
      fromBlock: from,
      toBlock: to,
      topics: [transferTopic]
    });

    const eventsByToken = {};
    for (const l of logs) {
      const token = l.address.toLowerCase();
      const valueHex = l.data;
      let valueEth = 0;
      try { valueEth = Number(BigInt(valueHex)) / 1e18; } catch {}
      if (!eventsByToken[token]) eventsByToken[token] = [];
      const fromAddr = '0x' + l.topics[1].slice(26);
      const toAddr   = '0x' + l.topics[2].slice(26);
      eventsByToken[token].push({
        wallet: fromAddr.toLowerCase(),
        to: toAddr.toLowerCase(),
        valueEth,
        blockNumber: l.blockNumber,
        txHash: l.transactionHash
      });
    }

    for (const token of Object.keys(eventsByToken)) {
      const buys = eventsByToken[token].filter(e => e.valueEth >= Number(WHALER_MIN_ETH));
      if (buys.length === 0) continue;
      const last = recentSignals.get(token) || 0;
      const now = Date.now();
      if (now - last < 1000 * 60 * 10) continue;
      const sc = await scoreToken(token, buys);
      if (sc.score >= 50) {
        const text = `🚨 *Whale Accumulation*\nToken: \`${token}\`\nScore: ${sc.score}\nETH total: ${sc.totalEth}\nWhales: ${sc.uniqueWhales}\nHolders: ${sc.holders}\nTx count: ${buys.length}\nExample: https://etherscan.io/tx/${buys[0].txHash}`;
        await sendTelegram(text);
        recentSignals.set(token, now);
        console.log("Alert sent for", token, sc);
      } else {
        console.log("Low score", token, sc.score);
      }
    }
  } catch (e) {
    console.error("pollRecentTransfers error:", e.message);
  }
}

app.post('/webhook/alchemy', async (req, res) => {
  console.log("Webhook received:", JSON.stringify(req.body).slice(0, 500));
  res.json({ ok: true });
});

app.get('/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`MemeWhaleWatcher running on port ${PORT}`);
  setInterval(pollRecentTransfers, 15_000);
});
