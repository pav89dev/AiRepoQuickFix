import os, json, re, base64, requests, time
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from solana.rpc.api import Client
from solana.keypair import Keypair
from solana.transaction import Transaction
from solana.rpc.types import TxOpts
from solana.publickey import PublicKey

# ---- CONFIG ----
TELEGRAM_TOKEN = "PASTE_YOUR_TELEGRAM_TOKEN"
SOLANA_KEYPAIR_PATH = os.path.expanduser("~/sol_key.json")
RPC_URL = "https://api.mainnet-beta.solana.com"
JUPITER_QUOTE_API = "https://quote-api.jup.ag/v4/quote"
JUPITER_SWAP_API = "https://quote-api.jup.ag/v4/swap"
SOL_MINT = "So11111111111111111111111111111111111111112"
# ----------------

solana_client = Client(RPC_URL)

# Load wallet
with open(SOLANA_KEYPAIR_PATH) as f:
    kp = Keypair.from_secret_key(bytes(json.load(f)))
WALLET = kp
PUBKEY = WALLET.public_key

def parse_command(text):
    """buy 0.01 SOL <TOKEN_MINT> tp 10% sl 50% repeat"""
    m = re.search(r"buy\s+([\d\.]+)\s+SOL\s+([A-Za-z0-9]+)", text, re.I)
    if not m: return None
    amount, token = float(m.group(1)), m.group(2)
    tp = re.search(r"tp\s*([\d\.]+)%", text, re.I)
    sl = re.search(r"sl\s*([\d\.]+)%", text, re.I)
    repeat = "repeat" in text.lower()
    return {
        "amount": amount,
        "token": token,
        "tp": float(tp.group(1)) if tp else 10.0,
        "sl": float(sl.group(1)) if sl else 50.0,
        "repeat": repeat
    }

def get_quote(input_mint, output_mint, amount):
    params = {"inputMint": input_mint, "outputMint": output_mint, "amount": str(amount), "slippageBps": "500"}
    return requests.get(JUPITER_QUOTE_API, params=params).json()

def get_swap(route):
    payload = {"route": route, "userPublicKey": str(PUBKEY), "wrapUnwrapSOL": True}
    return requests.post(JUPITER_SWAP_API, json=payload).json()

def send_tx(base64_tx):
    raw = base64.b64decode(base64_tx)
    tx = Transaction.deserialize(raw)
    tx.sign(WALLET)
    signed = tx.serialize()
    return solana_client.send_raw_transaction(signed, opts=TxOpts(skip_confirmation=False))

def execute_swap(input_mint, output_mint, raw_amount):
    q = get_quote(input_mint, output_mint, raw_amount)
    if not q.get("data"): return None
    route = q["data"][0]
    swap = get_swap(route)
    if "swapTransaction" not in swap: return None
    return send_tx(swap["swapTransaction"])

def get_token_decimals(token_mint):
    if token_mint == SOL_MINT:
        return 9
    res = solana_client.get_token_supply(PublicKey(token_mint))
    return int(res["result"]["value"]["decimals"])

def get_token_balance(token_mint):
    if token_mint == SOL_MINT:
        bal = solana_client.get_balance(PUBKEY)["result"]["value"]
        return bal / 1e9
    res = solana_client.get_token_accounts_by_owner(PUBKEY, {"mint": token_mint})
    if not res["result"]["value"]: 
        return 0.0
    acc = res["result"]["value"][0]["pubkey"]
    bal = solana_client.get_token_account_balance(PublicKey(acc))
    return float(bal["result"]["value"]["uiAmount"])

def monitor(cfg, sendmsg):
    while True:
        sendmsg(f"Buying {cfg['amount']} SOL of token {cfg['token']}")
        lamports = int(cfg["amount"] * 1e9)
        buy_res = execute_swap(SOL_MINT, cfg["token"], lamports)
        if not buy_res: 
            sendmsg("Buy failed")
            return
        sendmsg(f"Buy tx: {buy_res}")

        entry_value = cfg["amount"]  # SOL spent
        while True:
            time.sleep(2)
            token_bal = get_token_balance(cfg["token"])
            if token_bal <= 0:
                sendmsg("No token balance, stopping.")
                return

            decimals = get_token_decimals(cfg["token"])
            q = get_quote(cfg["token"], SOL_MINT, int(token_bal * (10 ** decimals)))
            if not q.get("data"): 
                sendmsg("No quote")
                continue
            sol_now = float(q["data"][0]["outAmount"]) / 1e9
            change = (sol_now - entry_value) / entry_value * 100
            sendmsg(f"PnL: {change:.2f}% (TP {cfg['tp']}%, SL {cfg['sl']}%)")

            if change >= cfg["tp"]:
                sendmsg("🎯 TP hit! Selling...")
                sell_res = execute_swap(cfg["token"], SOL_MINT, int(token_bal * (10 ** decimals)))
                sendmsg(f"Sell tx: {sell_res}")
                if cfg["repeat"]: break
                else: return
            if change <= -cfg["sl"]:
                sendmsg("⛔ SL hit! Selling & stopping...")
                sell_res = execute_swap(cfg["token"], SOL_MINT, int(token_bal * (10 ** decimals)))
                sendmsg(f"Sell tx: {sell_res}")
                return

def handle(update, ctx):
    cfg = parse_command(update.message.text)
    if not cfg:
        update.message.reply_text("Format: buy 0.01 SOL <TOKEN_MINT> tp 10% sl 50% repeat")
        return
    def sendmsg(msg): update.message.reply_text(msg)
    sendmsg(f"Config: {cfg}")
    monitor(cfg, sendmsg)

def start(update, ctx): update.message.reply_text("Send: buy 0.01 SOL <TOKEN_MINT> tp 10% sl 50% repeat")

updater = Updater(TELEGRAM_TOKEN)
dp = updater.dispatcher
dp.add_handler(CommandHandler("start", start))
dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle))
updater.start_polling()
updater.idle()
