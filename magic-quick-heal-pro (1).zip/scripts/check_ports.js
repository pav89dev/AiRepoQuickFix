// Dummy check for port usage
console.log("✅ Ports check passed (stub)");
